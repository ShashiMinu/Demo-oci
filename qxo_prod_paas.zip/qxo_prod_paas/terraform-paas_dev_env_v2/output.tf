output "integration_instance_id" {
  value = module.dgdevoic.integration_instance_id
}

output "autonomous_database_id" {
  value       = module.atp.autonomous_database_id
}
output "db_name" {
  value = module.atp.db_name
}
output "db_state" {
  value = module.atp.db_state
}
output "db_conn" {
  value = module.atp.db_conn
}

output "data_safe_private_endpoint_id" {
  description = "List of Data Safe Private Endpoint OCIDs"
  value       = module.data_safe_private_endpoint.data_safe_private_endpoint_id
}
output "datasafe_target_databases" {
  description = "All created Data Safe target databases"
  value       = module.data_safe_target_database.datasafe_target_databases
}

output "atp_admin_secret_id" {
  value = module.vault.atp_admin_secret_id
}