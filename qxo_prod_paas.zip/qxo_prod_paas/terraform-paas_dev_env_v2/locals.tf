data "oci_identity_compartments" "compartments" {
  # This should be your tenancy OCID (or the OCID of the parent compartment)
  compartment_id = var.tenancy_ocid

  # Enable retrieving all compartments in the subtree.
  # This returns all subcompartments regardless of how deep they are nested.
  compartment_id_in_subtree = true

  access_level = "ACCESSIBLE"
}

locals {
  # This converts the list of compartments into a map where each key is the compartment name
  # and the value is the compartment's OCID.
  compartment_map = {
    for comp in data.oci_identity_compartments.compartments.compartments :
    comp.name => comp.id
  }
}
