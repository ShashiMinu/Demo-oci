terraform {
  #required_version = ">=1.10.5"
  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">=6.23.0"
    }
  }
}

provider "oci" {
  region           = var.region
  tenancy_ocid     = var.tenancy_ocid
  #user_ocid        = var.user_ocid
  #fingerprint      = var.fingerprint
  #private_key_path = pathexpand(var.private_key_path)

}
