########################
# ENVIRONMENT : PROD
########################

data "oci_identity_tenancy" "this" {
  tenancy_id = var.tenancy_ocid != null ? var.tenancy_ocid : null
}

data "oci_identity_compartments" "prod_compartment" {
  compartment_id            = data.oci_identity_tenancy.this.id
  compartment_id_in_subtree = true
 
  filter {
    name   = "name"
    values = [var.prod_compartment_name]
  }
}
 
locals {
  prod_compartment_id = try(data.oci_identity_compartments.prod_compartment.compartments[0].id, null)
}
 

data "oci_identity_domains" "my_domain" {
  compartment_id = local.prod_compartment_id != null ? local.prod_compartment_id : data.oci_identity_tenancy.this.id
 
  filter {
    name   = "display_name"
    values = [var.identity_domain_name]
  }
}
 
locals {
  domain_id = try(data.oci_identity_domains.my_domain.domains[0].id, null)
}
 
resource "oci_identity_domain_replication_to_region" "test_domain_replication_to_region" {
  # Don't create it unless we actually found a domain
  count          = local.domain_id != null ? 1 : 0
 
  domain_id      = local.domain_id
  replica_region = var.secondary_region
}

###################################################
#     PROD ATP DATABASE
####################################################

module "atp" {
  source                      = "./modules/atp"
  tenancy_ocid                = var.tenancy_ocid
  atp_compartment_name        = var.atp_compartment_name
  atp_vcn_compartment_name    = var.atp_vcn_compartment_name
  atp_vcn_name                = var.atp_vcn_name
  db_version                  = var.db_version
  admin_password_secret_id    =  module.vault.atp_admin_secret_id
  db_name                     = var.db_name
  display_name                = var.display_name
  db_workload                 = var.db_workload
  compute_count               = var.compute_count
  data_storage_size_in_tbs    = var.data_storage_size_in_tbs
  compute_model               = var.compute_model
  is_dedicated                = var.is_dedicated
  is_mtls_connection_required = var.is_mtls_connection_required
  license_model               = var.license_model
  is_data_guard_enabled       = var.is_data_guard_enabled
  is_local_data_guard_enabled = var.is_local_data_guard_enabled
  is_auto_scaling_enabled     = var.is_auto_scaling_enabled
  backup_retention_period_in_days      = var.backup_retention_period_in_days
  autonomous_maintenance_schedule_type = var.autonomous_maintenance_schedule_type
  character_set                       = var.character_set
  ncharacter_set                      = var.ncharacter_set
  atp_subnet_name             = var.atp_subnet_name
  whitelisted_ips             = var.whitelisted_ips
  freeform_tags               = var.freeform_tags
  emails                      = var.emails

}

################################
#   PROD OIC
################################

module "dgdevoic" {
  source                    = "./modules/oic"
  tenancy_ocid              = var.tenancy_ocid
  oic_compartment_name      = var.oic_compartment_name
  oic_domain_compartment    = var.oic_domain_compartment
  oic_display_name          = var.oic_display_name
  integration_instance_type = var.integration_instance_type
  message_packs             = var.message_packs
  shape                     = var.shape
  is_byol                   = var.is_byol
  domain_name               = var.domain_name
  freeform_tags             = var.freeform_tags
  is_disaster_recovery_enabled = var.is_disaster_recovery_enabled
  is_file_server_enabled       = var.is_file_server_enabled
  is_visual_builder_enabled    = var.is_visual_builder_enabled
}

################################
# Data Safe Private Endpoint
################################
module "data_safe_private_endpoint" {
  source       = "./modules/data_safe_private_endpoint"
  depends_on   = [module.atp]
  tenancy_ocid = var.tenancy_ocid
  data_safe_private_endpoints = var.data_safe_private_endpoints
}

################################
# Data Safe Target Database
################################
module "data_safe_target_database" {
  source       = "./modules/data_safe_target_database"
  depends_on   = [
    module.data_safe_private_endpoint,
    module.atp
  ]
  tenancy_ocid = var.tenancy_ocid

  target_databases = [
    for i, db in var.target_databases : merge(db, {
      database_details = merge(db.database_details, {
       autonomous_database_id = module.atp.autonomous_database_id
      })
      connection_option = merge(db.connection_option, {
       #datasafe_private_endpoint_id = module.data_safe_private_endpoint.data_safe_private_endpoint_id
        datasafe_private_endpoint_id = one(module.data_safe_private_endpoint.data_safe_private_endpoint_id)

      })
    })
  ]
}

module "vault" {
  source                      = "./modules/vault"
  tenancy_ocid                = var.tenancy_ocid
  vault_compartment_name      = var.vault_compartment_name
  vault_display_name          = var.vault_display_name
  vault_type                  = var.vault_type
  secret_name                 = var.secret_name
  password_length             =var.password_length
  key_display_name = var.key_display_name

}






