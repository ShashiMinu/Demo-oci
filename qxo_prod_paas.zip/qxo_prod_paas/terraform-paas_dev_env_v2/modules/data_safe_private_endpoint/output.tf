
output "data_safe_private_endpoint_id" {
  description = "List of Data Safe Private Endpoint OCIDs"
  value       = [for pe in oci_data_safe_data_safe_private_endpoint.data_safe_private_endpoint : pe.id]
}

output "data_safe_private_endpoints" {
  description = "Details of the provisioned Data Safe private endpoints."
  value = {
    for idx, inst in oci_data_safe_data_safe_private_endpoint.data_safe_private_endpoint :
    idx => {
      id                  = inst.id
      display_name        = inst.display_name
      compartment_id      = inst.compartment_id
      vcn_id              = inst.vcn_id
      subnet_id           = inst.subnet_id
      nsg_ids             = inst.nsg_ids
      private_endpoint_ip = inst.private_endpoint_ip
      description         = inst.description
      defined_tags        = inst.defined_tags
      freeform_tags       = inst.freeform_tags
      state               = inst.state
    }
  }
}

output "vcn_details" {
  description = "Details of the VCNs associated with the Data Safe private endpoints."
  value = {
    for idx, vcn in local.data_safe_vcn :
    idx => vcn != null ? {
      id            = vcn.id
      display_name  = vcn.display_name
      compartment_id = vcn.compartment_id
    } : null
  }
}

output "subnet_details" {
  description = "Details of the subnets associated with the Data Safe private endpoints."
  value = {
    for idx, subnet in local.data_safe_subnet :
    idx => subnet != null ? {
      id            = subnet.id
      display_name  = subnet.display_name
      compartment_id = subnet.compartment_id
      vcn_id        = subnet.vcn_id
    } : null
  }
}

output "nsg_details" {
  description = "Details of the network security groups (NSGs) associated with the Data Safe private endpoints."
  value = {
    for idx, nsg_ids in local.data_safe_nsg :
    idx => [
      for id in nsg_ids : {
        id = id
      }
    ]
  }
}

output "compartment_details" {
  description = "Details of the compartments used for Data Safe private endpoints."
  value = {
    for idx, comp in data.oci_identity_compartments.data_safe_compartment :
    idx => length(comp.compartments) > 0 ? {
      id   = comp.compartments[0].id
      name = comp.compartments[0].name
    } : null
  }
}

output "vcn_compartment_details" {
  description = "Details of the compartments used for VCNs."
  value = {
    for idx, comp in data.oci_identity_compartments.data_safe_vcn_compartment :
    idx => length(comp.compartments) > 0 ? {
      id   = comp.compartments[0].id
      name = comp.compartments[0].name
    } : null
  }
}

output "tenancy_id" {
  description = "The OCID of the tenancy."
  value       = data.oci_identity_tenancy.this.id
}