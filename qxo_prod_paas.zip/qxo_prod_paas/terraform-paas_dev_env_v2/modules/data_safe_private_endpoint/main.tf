# Lookup tenancy
data "oci_identity_tenancy" "this" {
  tenancy_id = var.tenancy_ocid
}

# Lookup compartment for each Data Safe private endpoint
data "oci_identity_compartments" "data_safe_compartment" {
  for_each = { for idx, inst in var.data_safe_private_endpoints : idx => inst }
  compartment_id            = data.oci_identity_tenancy.this.id
  compartment_id_in_subtree = true
  filter {
    name   = "name"
    values = [each.value.compartment_name]
  }
}

# Lookup compartment for each VCN
data "oci_identity_compartments" "data_safe_vcn_compartment" {
  for_each = { for idx, inst in var.data_safe_private_endpoints : idx => inst }
  compartment_id            = data.oci_identity_tenancy.this.id
  compartment_id_in_subtree = true
  filter {
    name   = "name"
    values = [each.value.vcn_compartment_name]
  }
}

# Lookup VCN by name for each private endpoint
data "oci_core_virtual_networks" "vcn" {
  for_each       = { for idx, inst in var.data_safe_private_endpoints : idx => inst }
  compartment_id = length(data.oci_identity_compartments.data_safe_vcn_compartment[each.key].compartments) > 0 ? data.oci_identity_compartments.data_safe_vcn_compartment[each.key].compartments[0].id : ""
  filter {
    name   = "display_name"
    values = [each.value.vcn_name]
  }
}

locals {
  data_safe_vcn = {
    for idx, inst in var.data_safe_private_endpoints :
    idx => length(data.oci_core_virtual_networks.vcn[idx].virtual_networks) > 0 ? data.oci_core_virtual_networks.vcn[idx].virtual_networks[0] : null
  }
}

# Lookup Subnet by name for each private endpoint
data "oci_core_subnets" "subnet" {
  for_each       = { for idx, inst in var.data_safe_private_endpoints : idx => inst }
  compartment_id = length(data.oci_identity_compartments.data_safe_vcn_compartment[each.key].compartments) > 0 ? data.oci_identity_compartments.data_safe_vcn_compartment[each.key].compartments[0].id : ""
  vcn_id         = local.data_safe_vcn[each.key] != null ? local.data_safe_vcn[each.key].id : null
  filter {
    name   = "display_name"
    values = [each.value.subnet_name]
  }
  depends_on = [data.oci_core_virtual_networks.vcn]
}

locals {
  data_safe_subnet = {
    for idx, inst in var.data_safe_private_endpoints :
    idx => length(data.oci_core_subnets.subnet[idx].subnets) > 0 ? data.oci_core_subnets.subnet[idx].subnets[0] : null
  }
}

# Lookup NSG by name for each private endpoint
data "oci_core_network_security_groups" "nsg" {
  for_each       = { for idx, inst in var.data_safe_private_endpoints : idx => inst }
  compartment_id = length(data.oci_identity_compartments.data_safe_vcn_compartment[each.key].compartments) > 0 ? data.oci_identity_compartments.data_safe_vcn_compartment[each.key].compartments[0].id : ""
  vcn_id         = local.data_safe_vcn[each.key] != null ? local.data_safe_vcn[each.key].id : null
  depends_on = [data.oci_core_virtual_networks.vcn]
}

locals {
  data_safe_nsg = {
    for idx, inst in var.data_safe_private_endpoints :
    idx => length(inst.nsg_names) > 0 ? [
      for n in data.oci_core_network_security_groups.nsg[idx].network_security_groups :
      n.id if contains(inst.nsg_names, n.display_name)
    ] : []
  }
}

# Provision Data Safe private endpoint for each instance
resource "oci_data_safe_data_safe_private_endpoint" "data_safe_private_endpoint" {
  for_each = { for idx, inst in var.data_safe_private_endpoints : idx => inst }

  # Required
  compartment_id = length(data.oci_identity_compartments.data_safe_compartment[each.key].compartments) > 0 ? data.oci_identity_compartments.data_safe_compartment[each.key].compartments[0].id : null
  display_name   = each.value.display_name
  subnet_id      = local.data_safe_subnet[each.key] != null ? local.data_safe_subnet[each.key].id : null
  vcn_id         = local.data_safe_vcn[each.key] != null ? local.data_safe_vcn[each.key].id : null

  # Optional
  defined_tags        = each.value.defined_tags != null ? each.value.defined_tags : {}
  description         = each.value.description != null ? each.value.description : ""
  freeform_tags       = each.value.freeform_tags != null ? each.value.freeform_tags : {}
  nsg_ids             = length(local.data_safe_nsg[each.key]) > 0 ? local.data_safe_nsg[each.key] : null
  private_endpoint_ip = each.value.private_endpoint_ip != null ? each.value.private_endpoint_ip : null

  # Validate required attributes to prevent resource creation with invalid inputs
  lifecycle {
    precondition {
      condition     = local.data_safe_vcn[each.key] != null && local.data_safe_subnet[each.key] != null
      error_message = "Cannot create Data Safe private endpoint for index ${each.key}: VCN or subnet is not found."
    }
    prevent_destroy = true
    ignore_changes = [
      private_endpoint_ip,
      defined_tags
    ]
  }

  depends_on = [data.oci_core_subnets.subnet, data.oci_core_network_security_groups.nsg]
}