variable "tenancy_ocid" {
  type        = string
  description = "The OCID of the tenancy where resources will be provisioned."
}

variable "data_safe_private_endpoints" {
  type = list(object({
    compartment_name     = string
    vcn_compartment_name = string
    vcn_name             = string
    subnet_name          = string
    display_name         = string
    description          = string
    defined_tags         = optional(map(string), {})
    freeform_tags        = optional(map(string), {})
    nsg_names            = optional(list(string), [])
    private_endpoint_ip  = optional(string)
  }))
  description = "List of Data Safe private endpoints to provision, including compartment, VCN, subnet, and other configuration details."
  default     = []
}