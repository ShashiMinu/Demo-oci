output "datasafe_target_databases" {
  description = "All created Data Safe target databases"
  value       = oci_data_safe_target_database.target_database[*].id
}
