# Lookup tenancy
data "oci_identity_tenancy" "this" {
  tenancy_id = var.tenancy_ocid
}

# Lookup compartment for each target database
data "oci_identity_compartments" "target_compartment" {
  for_each = { for idx, db in var.target_databases : idx => db }
  compartment_id            = data.oci_identity_tenancy.this.id
  compartment_id_in_subtree = true
  filter {
    name   = "name"
    values = [each.value.compartment_name]
  }
}

# Lookup Autonomous Database by name for each target database
data "oci_database_autonomous_databases" "autonomous_db" {
  for_each       = { for idx, db in var.target_databases : idx => db }
  compartment_id = data.oci_identity_compartments.target_compartment[each.key].compartments[0].id
}
/*
locals {
  target_autonomous_db = {
    for idx, db in var.target_databases :
    idx => [
      for adb in data.oci_database_autonomous_databases.autonomous_db[idx].autonomous_databases :
      adb.id if adb.display_name == db.autonomous_database_name
    ][0]
  }
}*/

locals {
  target_autonomous_db = {
    for idx, db in var.target_databases :
    idx => one([
      for adb in data.oci_database_autonomous_databases.autonomous_db[idx].autonomous_databases :
      adb.id
      if adb.display_name == db.autonomous_database_name
    ])
  }
}

# Provision Data Safe target database for each instance
resource "oci_data_safe_target_database" "target_database" {
  count = length(var.target_databases)

  compartment_id = data.oci_identity_compartments.target_compartment[tostring(count.index)].compartments[0].id

  database_details {
    database_type          = var.target_databases[count.index].database_details.database_type
    infrastructure_type    = var.target_databases[count.index].database_details.infrastructure_type
    autonomous_database_id = coalesce(
      var.target_databases[count.index].database_details.autonomous_database_id,
      local.target_autonomous_db[tostring(count.index)]
    )
  }

  connection_option {
    connection_type              = var.target_databases[count.index].connection_option.connection_type
    datasafe_private_endpoint_id = var.target_databases[count.index].connection_option.datasafe_private_endpoint_id
  }

  display_name  = var.target_databases[count.index].display_name
  description   = var.target_databases[count.index].description
  defined_tags  = var.target_databases[count.index].defined_tags
  freeform_tags = var.target_databases[count.index].freeform_tags
 lifecycle {
    prevent_destroy = true
    ignore_changes = [
      freeform_tags,
      defined_tags
    ]
  }
 
 

}
