variable "tenancy_ocid" {
  description = "The tenancy OCID."
  type        = string
}

variable "target_databases" {
  description = "List of Data Safe target databases"
  type = list(object({
    display_name             = string
    description              = string
    compartment_name         = string
    autonomous_database_name = string

    database_details = object({
      database_type          = string
      infrastructure_type    = string
      autonomous_database_id = optional(string)
    })

    connection_option = object({
      connection_type                = string
      datasafe_private_endpoint_id   = optional(string)
      datasafe_private_endpoint_name = optional(string)
    })

    defined_tags  = optional(map(string))
    freeform_tags = optional(map(string))
  }))
}
