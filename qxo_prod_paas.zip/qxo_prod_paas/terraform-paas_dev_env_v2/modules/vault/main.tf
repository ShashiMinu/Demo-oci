data "oci_identity_tenancy" "this" {
  tenancy_id = var.tenancy_ocid != null ? var.tenancy_ocid : null
}

data "oci_identity_compartments" "vault_compartment" {
  compartment_id            = data.oci_identity_tenancy.this.id
  compartment_id_in_subtree = true
  filter {
    name   = "name"
    values = [var.vault_compartment_name]
  }
}


locals {
  vault_compartment_id = data.oci_identity_compartments.vault_compartment.compartments[0].id
}

resource "oci_kms_vault" "atp_vault" {
  compartment_id = try(local.vault_compartment_id, null)
  display_name   = var.vault_display_name
  vault_type     = var.vault_type
  lifecycle {
    ignore_changes = all 
    prevent_destroy = true
  }
}

resource "time_sleep" "wait_for_vault" {
  depends_on = [oci_kms_vault.atp_vault]
  create_duration = "60s"
}

resource "oci_kms_key" "atp_key" {
  compartment_id      = local.vault_compartment_id
  display_name        = var.key_display_name
  management_endpoint = oci_kms_vault.atp_vault.management_endpoint

  key_shape {
    algorithm = "AES"
    length    = 32
  }
  lifecycle {
    ignore_changes = all 
    prevent_destroy = true
  }
}

resource "random_password" "atp_admin_password" {
  length           = var.password_length
  special          = true
  override_special = "#"
}

resource "oci_vault_secret" "atp_admin_secret" {
  compartment_id = try(local.vault_compartment_id, null)
  vault_id       = oci_kms_vault.atp_vault.id
  key_id         = oci_kms_key.atp_key.id
  secret_name    = var.secret_name

  secret_content {
    content_type = "BASE64"
    content      = base64encode(random_password.atp_admin_password.result)
  }

  lifecycle {
    ignore_changes = all 
    prevent_destroy = true
  }
}
