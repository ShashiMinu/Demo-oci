output "atp_admin_secret_id" {
  value = oci_vault_secret.atp_admin_secret.id
}