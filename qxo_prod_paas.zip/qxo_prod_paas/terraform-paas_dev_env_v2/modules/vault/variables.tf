

variable "tenancy_ocid" {
  description = "OCI Tenancy OCID"
  type        = string
}


variable "vault_compartment_name" {
  description = "Compartment Name in which this vault will be created"
  type        = string
}

variable "vault_display_name" {
  description = "display name the of vault "
  type        = string
}

variable "vault_type" {
  description = "display name the of vault "
  type        = string
}

variable "key_display_name" {
  description = "display name the of key inside the vault"
  type        = string
}

variable"secret_name"{
  type = string
}
variable "password_length"{
  type =string
}


