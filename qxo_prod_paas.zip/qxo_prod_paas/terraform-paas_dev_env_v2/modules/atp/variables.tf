
#################################
# Variables Configuration
#################################

variable "tenancy_ocid" {
  type        = string
  description = "Compartment in which this ATP database will be created"
}

variable "db_version" {
  type        = string
  description = "Database version to be used for this ATP Database"
}
variable "db_name" {
  type        = string
  description = "ATP Database name to be used"
}
variable "display_name" {
  type        = string
  description = "Display name for the ATP database"
}
variable "db_workload" {
  type        = string
  description = "Workload type OLTP or something else"
}
variable "compute_count" {
  type        = number
  description = "CPU count in terms of ECPU for the ETP Database"
}
variable "data_storage_size_in_tbs" {
  type        = number
  description = "Database storage in TB"
}
variable "compute_model" {
  type    = string
  default = "Compute model for the ATP Database (ECPU)"
}
variable "is_dedicated" {
  type        = string
  description = "Is it a dedicated ATP database - true or false, For shared it must be false"
}
variable "is_mtls_connection_required" {
  type        = string
  description = "This value must be true false, if mtls connection required it must true else false"
}
variable "license_model" {
  type        = string
  description = "Licensing model either license included or BYOL"
}
variable "is_data_guard_enabled" {
  type        = string
  description = "Is remote dataguard needed?, Either true or false."
}
variable "is_local_data_guard_enabled" {
  type        = string
  description = "Is local dataguard enabled?, either true or false"
}
variable "whitelisted_ips" {
  type        = list(string)
  description = "List of IPs allowed over public internet using ACL"
}

variable "emails" {
  type        = string
  description = "Email to which notifications are sent."
}
variable "freeform_tags" {
  type        = map(string)
  description = "Freeform tags to be used for this database"
}

variable "atp_compartment_name" {
  type        = string
  description = "Compartment name in which this database will be created"
}

variable "atp_vcn_name" {
  type        = string
  description = "VCN to be used to create private endpoint"
}

variable "atp_subnet_name" {
  type        = string
  description = "Subnet to be used to create ATP private endpoint"
}

variable "atp_vcn_compartment_name" {
  type        = string
  description = "Compartment name in which this database will be created"
}
variable "is_auto_scaling_enabled" {
  type        = string
  description = "This value must be true false, if auto scaling is  required it must true"
}
variable "backup_retention_period_in_days" {
  description = "Number of days to retain backups"
  type        = number
}

variable "autonomous_maintenance_schedule_type" {
  description = "Autonomous database maintenance schedule type"
  type        = string
}
variable "admin_password_secret_id" {
  type        = string
  description = "OCID of the Vault secret for ATP admin password"
}

variable "character_set" {
  description = "Database character set"
  type        = string
}

variable "ncharacter_set" {
  description = "Database national character set"
  type        = string
}
