######################################
# TENANCY AND COMPARTMENT LOOKUPS
######################################

data "oci_identity_tenancy" "this" {
  tenancy_id = var.tenancy_ocid != null ? var.tenancy_ocid : null
}

data "oci_identity_compartments" "atp_compartment" {
  compartment_id            = data.oci_identity_tenancy.this.id
  compartment_id_in_subtree = true
  filter {
    name   = "name"
    values = [var.atp_compartment_name]
  }
}

data "oci_identity_compartments" "atp_vcn_compartment" {
  compartment_id            = data.oci_identity_tenancy.this.id
  compartment_id_in_subtree = true
  filter {
    name   = "name"
    values = [var.atp_vcn_compartment_name]
  }
}

######################################
# COMPARTMENT LOCAL VARIABLES
######################################

locals {
  atp_compartment_id = data.oci_identity_compartments.atp_compartment.compartments[0].id
}

locals {
  atp_vcn_compartment_id = data.oci_identity_compartments.atp_vcn_compartment.compartments[0].id
}

data "oci_core_virtual_networks" "all" {
  compartment_id = local.atp_vcn_compartment_id
}

locals {
  filtered_vcns = [
    for v in data.oci_core_virtual_networks.all.virtual_networks : v
    if v.display_name == var.atp_vcn_name
  ]
  vcn = length(local.filtered_vcns) > 0 ? local.filtered_vcns[0] : null
}

######################################
# VCN AND SUBNET LOOKUPS
######################################

data "oci_core_subnets" "all" {
  compartment_id = local.atp_vcn_compartment_id
  vcn_id         = local.vcn.id
}

locals {
  filtered_subnet = [
    for s in data.oci_core_subnets.all.subnets : s
    if s.display_name == var.atp_subnet_name
  ]
  subnet = length(local.filtered_subnet) > 0 ? local.filtered_subnet[0] : null
}




######################################
# AUTONOMOUS DATABASE RESOURCE
######################################

resource "oci_database_autonomous_database" "atp_db" {
  #admin_password              = var.admin_password
  secret_id = var.admin_password_secret_id
  compartment_id              = local.atp_compartment_id
  compute_count               = var.compute_count
  compute_model               = var.compute_model
  data_storage_size_in_tbs    = var.data_storage_size_in_tbs
  db_name                     = var.db_name
  db_version                  = var.db_version
  db_workload                 = var.db_workload
  display_name                = var.display_name
  is_dedicated                = var.is_dedicated
  is_mtls_connection_required = var.is_mtls_connection_required
  license_model               = var.license_model
  whitelisted_ips             = var.whitelisted_ips
  is_data_guard_enabled       = var.is_data_guard_enabled
  is_local_data_guard_enabled = var.is_local_data_guard_enabled
  is_auto_scaling_enabled     = var.is_auto_scaling_enabled 
  backup_retention_period_in_days      = var.backup_retention_period_in_days
  autonomous_maintenance_schedule_type = var.autonomous_maintenance_schedule_type
  character_set                       = var.character_set
  ncharacter_set                      = var.ncharacter_set
  subnet_id                   = local.subnet.id
  freeform_tags               = var.freeform_tags
  customer_contacts {
    email = var.emails
  }
  lifecycle {  
   prevent_destroy = true
    ignore_changes = [defined_tags,
    freeform_tags
    ]
  }
}



