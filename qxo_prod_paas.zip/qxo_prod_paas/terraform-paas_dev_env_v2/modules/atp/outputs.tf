####################################
# Output Values
####################################


output "autonomous_database_id" {
  value       = oci_database_autonomous_database.atp_db.id
  description = "Route Table Id"
}

output "db_name" {
  value = oci_database_autonomous_database.atp_db.display_name
}
output "db_state" {
  value = oci_database_autonomous_database.atp_db.state
}
output "db_conn" {
  value = oci_database_autonomous_database.atp_db.connection_urls
}
