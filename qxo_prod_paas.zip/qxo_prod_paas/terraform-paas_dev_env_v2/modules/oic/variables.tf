#################################
# Variables Configuration
#################################
variable "oic_display_name" {
  description = "OIC instance name"
  type        = string
}

variable "integration_instance_type" {
  description = "STANDARD or ENTERPRISE"
  type        = string
}

variable "is_disaster_recovery_enabled" {
  type        = string
  description = "This value must be true false, if mtls connection required it must true"
}

variable "is_visual_builder_enabled" {
  type        = string
  description = "This value must be true false, if visual builder required it must true"
}

variable "is_file_server_enabled" {
  type        = string
  description = "This value must be true false, if file server required it must true"
}

variable "shape" {
  description = "OIC shape (oc3 or oc4)"
  type        = string
}

variable "message_packs" {
  description = "Minimum 1"
  type        = number
}

variable "is_byol" {
  description = "Whether BYOL is enabled"
  type        = bool
}

variable "freeform_tags" {
  description = "Freeform tags for OIC"
  type        = map(string)
  default     = {}
}

variable "domain_name" {
  description = "The name of the identity domain"
  type        = string
}


variable "tenancy_ocid" {
  description = "Tenancy OCID"
  type        = string
}



variable "oic_compartment_name" {
  description = "Compartment Name in which this domain will be created"
  type        = string
}

variable "oic_domain_compartment" {
  description = "Compartment Name in which this domain will be created"
  type        = string
}

