##############################
# Output Values
##############################

output "integration_instance_id" {
  value = oci_integration_integration_instance.this.id
}
