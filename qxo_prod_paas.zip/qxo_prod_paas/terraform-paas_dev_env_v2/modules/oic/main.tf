######################################
# TENANCY AND COMPARTMENT LOOKUPS
######################################


data "oci_identity_tenancy" "this" {
  tenancy_id = var.tenancy_ocid != null ? var.tenancy_ocid : null
}

data "oci_identity_compartments" "oic_compartment" {
  compartment_id            = data.oci_identity_tenancy.this.id
  compartment_id_in_subtree = true
  filter {
    name   = "name"
    values = [var.oic_compartment_name]
  }
}

locals {
  oic_compartment_id = length(data.oci_identity_compartments.oic_compartment.compartments) > 0 ? data.oci_identity_compartments.oic_compartment.compartments[0].id : null
}

data "oci_identity_compartments" "oic_domain_compartment" {
  compartment_id            = data.oci_identity_tenancy.this.id
  compartment_id_in_subtree = true
  filter {
    name   = "name"
    values = [var.oic_domain_compartment]
  }
}

locals {
  oic_domain_compartment_id = length(data.oci_identity_compartments.oic_domain_compartment.compartments) > 0 ? data.oci_identity_compartments.oic_domain_compartment.compartments[0].id : null
}
######################################
# IDENTITY DOMAIN LOOKUP
######################################

data "oci_identity_domains" "all" {
  compartment_id = local.oic_domain_compartment_id
}

locals {
  filtered_domains = [
    for d in data.oci_identity_domains.all.domains : d
    if d.display_name == var.domain_name
  ]

  domain = length(local.filtered_domains) > 0 ? local.filtered_domains[0] : null
}

######################################
# OIC INTEGRATION INSTANCE RESOURCE
######################################

resource "oci_integration_integration_instance" "this" {
  compartment_id            = try(local.oic_compartment_id, null)
  display_name              = var.oic_display_name
  integration_instance_type = var.integration_instance_type
  shape                     = var.shape
  message_packs             = var.message_packs
  is_byol                   = var.is_byol
  domain_id                 = local.domain.id
  freeform_tags             = var.freeform_tags
  is_disaster_recovery_enabled = var.is_disaster_recovery_enabled
  is_file_server_enabled   = var.is_file_server_enabled
  is_visual_builder_enabled = var.is_visual_builder_enabled

  lifecycle {
    ignore_changes = all 
    prevent_destroy = true
  }
}