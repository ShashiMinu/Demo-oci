########################################
#           TENANCY SETTINGS           #
########################################

variable "tenancy_ocid" {
  description = "OCI Tenancy OCID"
  type        = string
}



/*variable "user_ocid" {
  description = "OCI User OCID"
  type        = string
}

variable "fingerprint" {
  description = "OCI API Key Fingerprint"
  type        = string
}

variable "private_key_path" {
  description = "Path to the private key"
  type        = string
}*/

variable "region" {
  description = "OCI region"
  type        = string
}
variable "secondary_region" {
  description = "OCI region"
  type        = string
}

variable "identity_domain_name"{
  type = string
}


variable "prod_compartment_name"{
  type = string
}



########################################
#        DEV ATP CONFIGURATION         #
########################################

variable "db_version" {
  type        = string
  description = "Database version to be used for this ATP Database"
}
variable "db_name" {
  type        = string
  description = "ATP Database name to be used"
}
variable "display_name" {
  type        = string
  description = "Display name for the ATP database"
}
variable "db_workload" {
  type        = string
  description = "Workload type OLTP or something else"
}
variable "compute_count" {
  type        = number
  description = "CPU count in terms of ECPU for the ETP Database"
}
variable "data_storage_size_in_tbs" {
  type        = number
  description = "Database storage in TB"
}
variable "compute_model" {
  type    = string
  default = "Compute model for the ATP Database (ECPU)"
}
variable "is_dedicated" {
  type        = string
  description = "Is it a dedicated ATP database - true or false"
}
variable "is_mtls_connection_required" {
  type        = string
  description = "This value must be true false, if mtls connection required it must true"
}

variable "is_disaster_recovery_enabled" {
  type        = string
  description = "This value must be true false, if mtls connection required it must true"
}

variable "is_visual_builder_enabled" {
  type        = string
  description = "This value must be true false, if visual builder required it must true"
}

variable "is_file_server_enabled" {
  type        = string
  description = "This value must be true false, if file server required it must true"
}

variable "backup_retention_period_in_days" {
  description = "Number of days to retain backups"
  type        = number
}

variable "autonomous_maintenance_schedule_type" {
  description = "Autonomous database maintenance schedule type"
  type        = string
}

variable "character_set" {
  description = "Database character set"
  type        = string
}

variable "ncharacter_set" {
  description = "Database national character set"
  type        = string
}


variable "is_auto_scaling_enabled" {
  type        = string
  description = "This value must be true false, if auto scaling is  required it must true"
}
variable "license_model" {
  type        = string
  description = "Licensing model either license included or BYOL"
}
variable "is_data_guard_enabled" {
  type        = string
  description = "Is remote dataguard needed?, Either true or false."
}
variable "is_local_data_guard_enabled" {
  type        = string
  description = "Is local dataguard enabled?, either true or false"
}
variable "whitelisted_ips" {
  type        = list(string)
  description = "List of IPs allowed over public internet using ACL"
}

variable "emails" {
  type        = string
  description = "Email to which notifications are sent."
}


variable "atp_compartment_name" {
  type        = string
  description = "Compartment name in which this database will be created"
}

variable "atp_vcn_compartment_name" {
  type        = string
  description = "Compartment name in which this database will be created"
}

variable "atp_vcn_name" {
  type        = string
  description = "VCN to be used to create private endpoint"
}

variable "atp_subnet_name" {
  type        = string
  description = "Subnet to be used to create ATP private endpoint"
}


###################################################
#     PROD OIC CONFIGURATION
####################################################

variable "oic_display_name" {
  description = "OIC instance name"
  type        = string
}

variable "integration_instance_type" {
  description = "STANDARD or ENTERPRISE"
  type        = string
}

variable "shape" {
  description = "OIC shape (oc3 or oc4)"
  type        = string
}

variable "message_packs" {
  description = "Minimum 1"
  type        = number
}

variable "is_byol" {
  description = "Whether BYOL is enabled"
  type        = bool
}

 variable "freeform_tags" {
   description = "Freeform tags for OIC"
  type        = map(string)
 default     = {}
 }

variable "domain_name" {
  description = "The name of the identity domain"
  type        = string
}

variable "oic_compartment_name" {
  description = "Compartment Name in which this domain will be created"
  type        = string
}

variable "oic_domain_compartment" {
  description = "Compartment Name in which this domain will be created"
  type        = string
}

variable "data_safe_private_endpoints" {
  type = list(object({
    compartment_name     = string
    vcn_compartment_name = string
    vcn_name             = string
    subnet_name          = string
    display_name         = string
    description          = string
    private_endpoint_ip  = optional(string)
    defined_tags         = optional(map(string), {})
    freeform_tags        = optional(map(string), {})
    nsg_names            = optional(list(string), [])

  }))
  description = "List of Data Safe private endpoints to provision, including compartment, VCN, subnet, and other configuration details."
  default     = []
}

variable "target_databases" {
  description = "List of Data Safe target databases"
  type = list(object({
    display_name             = string
    description              = string
    compartment_name         = string
    autonomous_database_name = string

    database_details = object({
      database_type          = string
      infrastructure_type    = string
      autonomous_database_id = optional(string)
    })

    connection_option = object({
      connection_type                = string
      datasafe_private_endpoint_id   = optional(string)
      datasafe_private_endpoint_name = optional(string)
    })

    defined_tags  = optional(map(string))
    freeform_tags = optional(map(string))
  }))
}


variable "vault_compartment_name" {
  description = "Compartment Name in which this domain will be created"
  type        = string
}

variable "vault_display_name" {
  description = "display name the of vault "
  type        = string
}

variable "vault_type" {
  description = "display name the of vault "
  type        = string
}

variable "key_display_name" {
  description = "display name the of key inside the vault"
  type        = string
}

variable"secret_name"{
  type = string
}

variable "password_length"{
  type=string
}












































