
########################################
#           TENANCY SETTINGS           #
########################################

tenancy_ocid     = "ocid1.tenancy.oc1..aaaaaaaafu4bqoy3ok23miogejjanoyqncbrh55d2o7eli55zn43lc4auxjq"#ocid1.tenancy.oc1..aaaaaaaafu4bqoy3ok23miogejjanoyqncbrh55d2o7eli55zn43lc4auxjq"                                 # Tenancy OCID to be updated
#user_ocid        = ""                                 # User OCID to be updated
#fingerprint      = ""                                 # Fingerprint of the user to be updated
#private_key_path = ""                                 # Private Key path to be updated
region           = "us-ashburn-1"

###enabling replication for non deault domains #####
secondary_region = "us-phoenix-1"
prod_compartment_name = "qxo-prod-cmp"
identity_domain_name = "qxo-prod-oic-domain"


###################################################
#     Prod ATP DATABASE
####################################################
atp_compartment_name        = "qxo-prod-atp-cmp"
atp_vcn_compartment_name    = "qxo-network-cmp"
atp_vcn_name                = "qxo-prod-vcn"
db_version                  = "19c"
db_name                     = "PRODATPDB"
display_name                = "qxo-prod-atp"
db_workload                 = "OLTP"
compute_count               = "2"
data_storage_size_in_tbs    = "1"
compute_model               = "ECPU"
is_dedicated                = "false"
is_mtls_connection_required = "false"
is_auto_scaling_enabled     = "true"
license_model               = "LICENSE_INCLUDED"
is_data_guard_enabled       = "false"
is_local_data_guard_enabled = "false"
backup_retention_period_in_days      = 60
autonomous_maintenance_schedule_type = "REGULAR"
character_set                        = "AL32UTF8"
ncharacter_set                       = "AL16UTF16"
atp_subnet_name = "qxo-prod-db-sn"
whitelisted_ips = []                         # IP's/CIDR to be updated here
emails          = "minumula.shashikanth@pwc.com"                         # Email ID to be updated here

################################
# PROD OIC
################################
oic_compartment_name      =  "qxo-prod-oic-cmp"
oic_domain_compartment    =  "qxo-prod-cmp"
oic_display_name          = "qxo-oic-prod"
integration_instance_type = "ENTERPRISEX"
message_packs             = 1
shape                     = "PRODUCTION"
is_byol                   = false
is_disaster_recovery_enabled = true
is_file_server_enabled = "false"
is_visual_builder_enabled = "false"
domain_name = "qxo-prod-oic-domain"
 freeform_tags = {

   technical_contact = "minumula.shashikanth@pwc.com"         # Email ID to be updated here
}

########################### OIC Variable Values ################################

data_safe_private_endpoints = [
  {
    compartment_name     = "qxo-network-cmp"
    vcn_compartment_name = "qxo-network-cmp"
    vcn_name             = "qxo-prod-vcn"
    subnet_name          = "qxo-prod-db-sn"
    display_name         = "prod-datasafe-endpoint"
    description          = "data safe end point for prod atp"
    private_endpoint_ip  = null
    defined_tags  = {}
    freeform_tags = {}
    nsg_names     = []
}
]


target_databases = [
  {
    display_name             = "prod-atp-datasafe-target"
    description              = "Data Safe target for Production ATP"
    compartment_name         = "qxo-network-cmp"
    autonomous_database_name = "qxo-prod-atp"

    database_details = {
      database_type          = "AUTONOMOUS_DATABASE"
      infrastructure_type    = "ORACLE_CLOUD"
      autonomous_database_id = null   # Optional if you're resolving by name elsewhere
       }

    connection_option = {
      connection_type                = "PRIVATE_ENDPOINT"
      datasafe_private_endpoint_name = "prod-datasafe-endpoint"
    }

   defined_tags  = {}
   freeform_tags = {}
    }
]


vault_compartment_name ="qxo-network-cmp"

  vault_display_name = "qxo-vault"
  key_display_name   = "prod-atp-master-key"
  secret_name        = "prod-atp-admin-password"
  password_length    = 16
  vault_type = "DEFAULT"



  






































